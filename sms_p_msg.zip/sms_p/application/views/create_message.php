<?php 
	require_once 'header.php';
?>
<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
				<h2>Create <span>Message</span></h2>
				<div class="nmessage_form">
					<form id="nmessage_form">
						<div class="form-group">					
							<div class="input-group clearfix">
								<?php
								$x =$this->myclass->get_lab();
								?>
							<select name="msg_lid">
									<option>Please Select Category</option>
								 <?php  
                      if(is_array($x)):
                        foreach($x as $key=>$val):
                      ?>
                      <option value="<?php echo $val['lab_id'];?>"><?php echo $val['lab_name'];?></option>

                      <?php  
                        endforeach;
                      endif;
                      ?>
                      </select>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group clearfix">
								<textarea type="text" class="form-control" placeholder="Add Message" name="msg_text" rows="8" cols="30" maxlength="300" id="textarea"></textarea> 
							</div>
							<div id="textarea_feedback"></div>
							<div class="input-group">				      
							  <button type="button" class="btn btn-primary msg_btn">Add Message</button>		      
							</div>
						</div>
					</form>
					<div class="err_nmessage"></div>
				</div>				
			</div>
			<!--<div class="col-lg-offset-1 col-md-5 col-sm-12 col-xs-12">
				<h2>Show <span>Message</span></h2>
			</div>-->
		</div>
	</div><br/>
</div>
<?php 
	require_once 'footer.php';
?>